﻿namespace Proj_FinacialLedger_202244106
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbltext1 = new System.Windows.Forms.Label();
            this.btnNew = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbxYear = new System.Windows.Forms.TextBox();
            this.tbxTargetAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxIncomeMoney = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxIncomeContent = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbIncome = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbExpenditure = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lbAll = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbxIncomeDay = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxIncomeMonth = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbxIncomeYear = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnIncome = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbxExpenditureDay = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbxExpenditureMonth = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbxExpenditureYear = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btnExpenditure = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.tbxExpenditureContent = new System.Windows.Forms.TextBox();
            this.tbxExpenditureMoney = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnShortExpenditure = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.btnShortIncome = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.tbxShortContent = new System.Windows.Forms.TextBox();
            this.tbxShortMoney = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblTotalExpenditure = new System.Windows.Forms.Label();
            this.lblTotalIncome = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbltext1
            // 
            this.lbltext1.AutoSize = true;
            this.lbltext1.Font = new System.Drawing.Font("HY견고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbltext1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lbltext1.Location = new System.Drawing.Point(13, 13);
            this.lbltext1.Name = "lbltext1";
            this.lbltext1.Size = new System.Drawing.Size(192, 21);
            this.lbltext1.TabIndex = 0;
            this.lbltext1.Text = "가계부 관리 시스템";
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.Orange;
            this.btnNew.FlatAppearance.BorderSize = 0;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.btnNew.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNew.Location = new System.Drawing.Point(200, 24);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(180, 23);
            this.btnNew.TabIndex = 1;
            this.btnNew.Text = "신규(초기화)";
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "연도:";
            // 
            // tbxYear
            // 
            this.tbxYear.Location = new System.Drawing.Point(50, 24);
            this.tbxYear.Name = "tbxYear";
            this.tbxYear.Size = new System.Drawing.Size(77, 21);
            this.tbxYear.TabIndex = 3;
            this.tbxYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbxTargetAmount
            // 
            this.tbxTargetAmount.Location = new System.Drawing.Point(50, 51);
            this.tbxTargetAmount.Name = "tbxTargetAmount";
            this.tbxTargetAmount.Size = new System.Drawing.Size(113, 21);
            this.tbxTargetAmount.TabIndex = 5;
            this.tbxTargetAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "목표액:";
            // 
            // tbxIncomeMoney
            // 
            this.tbxIncomeMoney.Location = new System.Drawing.Point(53, 78);
            this.tbxIncomeMoney.Name = "tbxIncomeMoney";
            this.tbxIncomeMoney.Size = new System.Drawing.Size(100, 21);
            this.tbxIncomeMoney.TabIndex = 9;
            this.tbxIncomeMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "금액:";
            // 
            // tbxIncomeContent
            // 
            this.tbxIncomeContent.Location = new System.Drawing.Point(53, 51);
            this.tbxIncomeContent.Name = "tbxIncomeContent";
            this.tbxIncomeContent.Size = new System.Drawing.Size(157, 21);
            this.tbxIncomeContent.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "내역:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(17, 278);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(732, 168);
            this.tabControl1.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lbIncome);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(724, 142);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "수입 내역";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lbIncome
            // 
            this.lbIncome.FormattingEnabled = true;
            this.lbIncome.ItemHeight = 12;
            this.lbIncome.Location = new System.Drawing.Point(4, 3);
            this.lbIncome.Name = "lbIncome";
            this.lbIncome.Size = new System.Drawing.Size(717, 136);
            this.lbIncome.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lbExpenditure);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(724, 142);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "지출 내역";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lbExpenditure
            // 
            this.lbExpenditure.FormattingEnabled = true;
            this.lbExpenditure.ItemHeight = 12;
            this.lbExpenditure.Location = new System.Drawing.Point(4, 3);
            this.lbExpenditure.Name = "lbExpenditure";
            this.lbExpenditure.Size = new System.Drawing.Size(717, 136);
            this.lbExpenditure.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lbAll);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(724, 142);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "전체 내역";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lbAll
            // 
            this.lbAll.FormattingEnabled = true;
            this.lbAll.ItemHeight = 12;
            this.lbAll.Location = new System.Drawing.Point(4, 4);
            this.lbAll.Name = "lbAll";
            this.lbAll.Size = new System.Drawing.Size(717, 136);
            this.lbAll.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.tbxIncomeDay);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbxIncomeMonth);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbxIncomeYear);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnIncome);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbxIncomeContent);
            this.groupBox1.Controls.Add(this.tbxIncomeMoney);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(21, 136);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(238, 127);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "수입 등록";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(213, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 12);
            this.label9.TabIndex = 21;
            this.label9.Text = "일";
            // 
            // tbxIncomeDay
            // 
            this.tbxIncomeDay.Location = new System.Drawing.Point(182, 24);
            this.tbxIncomeDay.Name = "tbxIncomeDay";
            this.tbxIncomeDay.Size = new System.Drawing.Size(25, 21);
            this.tbxIncomeDay.TabIndex = 20;
            this.tbxIncomeDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(159, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 12);
            this.label8.TabIndex = 19;
            this.label8.Text = "월";
            // 
            // tbxIncomeMonth
            // 
            this.tbxIncomeMonth.Location = new System.Drawing.Point(128, 24);
            this.tbxIncomeMonth.Name = "tbxIncomeMonth";
            this.tbxIncomeMonth.Size = new System.Drawing.Size(25, 21);
            this.tbxIncomeMonth.TabIndex = 18;
            this.tbxIncomeMonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(111, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 12);
            this.label7.TabIndex = 17;
            this.label7.Text = "년";
            // 
            // tbxIncomeYear
            // 
            this.tbxIncomeYear.Location = new System.Drawing.Point(53, 24);
            this.tbxIncomeYear.Name = "tbxIncomeYear";
            this.tbxIncomeYear.Size = new System.Drawing.Size(52, 21);
            this.tbxIncomeYear.TabIndex = 16;
            this.tbxIncomeYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 12);
            this.label6.TabIndex = 15;
            this.label6.Text = "날짜:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(159, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 12);
            this.label5.TabIndex = 14;
            this.label5.Text = "원";
            // 
            // btnIncome
            // 
            this.btnIncome.BackColor = System.Drawing.Color.ForestGreen;
            this.btnIncome.FlatAppearance.BorderSize = 0;
            this.btnIncome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIncome.Font = new System.Drawing.Font("HY견고딕", 9F, System.Drawing.FontStyle.Bold);
            this.btnIncome.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnIncome.Location = new System.Drawing.Point(53, 99);
            this.btnIncome.Name = "btnIncome";
            this.btnIncome.Size = new System.Drawing.Size(134, 23);
            this.btnIncome.TabIndex = 13;
            this.btnIncome.Text = "+ 수입 등록";
            this.btnIncome.UseVisualStyleBackColor = false;
            this.btnIncome.Click += new System.EventHandler(this.btnIncome_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tbxExpenditureDay);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.tbxExpenditureMonth);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.tbxExpenditureYear);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.btnExpenditure);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.tbxExpenditureContent);
            this.groupBox2.Controls.Add(this.tbxExpenditureMoney);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(265, 136);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(238, 127);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "지출 내용";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(213, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 12);
            this.label10.TabIndex = 21;
            this.label10.Text = "일";
            // 
            // tbxExpenditureDay
            // 
            this.tbxExpenditureDay.Location = new System.Drawing.Point(182, 24);
            this.tbxExpenditureDay.Name = "tbxExpenditureDay";
            this.tbxExpenditureDay.Size = new System.Drawing.Size(25, 21);
            this.tbxExpenditureDay.TabIndex = 20;
            this.tbxExpenditureDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(159, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 12);
            this.label11.TabIndex = 19;
            this.label11.Text = "월";
            // 
            // tbxExpenditureMonth
            // 
            this.tbxExpenditureMonth.Location = new System.Drawing.Point(128, 24);
            this.tbxExpenditureMonth.Name = "tbxExpenditureMonth";
            this.tbxExpenditureMonth.Size = new System.Drawing.Size(25, 21);
            this.tbxExpenditureMonth.TabIndex = 18;
            this.tbxExpenditureMonth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(111, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 12);
            this.label12.TabIndex = 17;
            this.label12.Text = "년";
            // 
            // tbxExpenditureYear
            // 
            this.tbxExpenditureYear.Location = new System.Drawing.Point(53, 24);
            this.tbxExpenditureYear.Name = "tbxExpenditureYear";
            this.tbxExpenditureYear.Size = new System.Drawing.Size(52, 21);
            this.tbxExpenditureYear.TabIndex = 16;
            this.tbxExpenditureYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 12);
            this.label13.TabIndex = 15;
            this.label13.Text = "날짜:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(159, 84);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 12);
            this.label14.TabIndex = 14;
            this.label14.Text = "원";
            // 
            // btnExpenditure
            // 
            this.btnExpenditure.BackColor = System.Drawing.Color.Red;
            this.btnExpenditure.FlatAppearance.BorderSize = 0;
            this.btnExpenditure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExpenditure.Font = new System.Drawing.Font("HY견고딕", 9F, System.Drawing.FontStyle.Bold);
            this.btnExpenditure.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnExpenditure.Location = new System.Drawing.Point(53, 99);
            this.btnExpenditure.Name = "btnExpenditure";
            this.btnExpenditure.Size = new System.Drawing.Size(134, 23);
            this.btnExpenditure.TabIndex = 13;
            this.btnExpenditure.Text = "- 지출 등록";
            this.btnExpenditure.UseVisualStyleBackColor = false;
            this.btnExpenditure.Click += new System.EventHandler(this.btnExpenditure_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 54);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 12);
            this.label15.TabIndex = 6;
            this.label15.Text = "내역:";
            // 
            // tbxExpenditureContent
            // 
            this.tbxExpenditureContent.Location = new System.Drawing.Point(53, 51);
            this.tbxExpenditureContent.Name = "tbxExpenditureContent";
            this.tbxExpenditureContent.Size = new System.Drawing.Size(157, 21);
            this.tbxExpenditureContent.TabIndex = 7;
            // 
            // tbxExpenditureMoney
            // 
            this.tbxExpenditureMoney.Location = new System.Drawing.Point(53, 78);
            this.tbxExpenditureMoney.Name = "tbxExpenditureMoney";
            this.tbxExpenditureMoney.Size = new System.Drawing.Size(100, 21);
            this.tbxExpenditureMoney.TabIndex = 9;
            this.tbxExpenditureMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 12);
            this.label16.TabIndex = 8;
            this.label16.Text = "금액:";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.SkyBlue;
            this.groupBox3.Controls.Add(this.btnShortExpenditure);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.btnShortIncome);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.tbxShortContent);
            this.groupBox3.Controls.Add(this.tbxShortMoney);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox3.Location = new System.Drawing.Point(511, 136);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(238, 127);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "빠른 입력 (오늘 날짜)";
            // 
            // btnShortExpenditure
            // 
            this.btnShortExpenditure.BackColor = System.Drawing.Color.Red;
            this.btnShortExpenditure.FlatAppearance.BorderSize = 0;
            this.btnShortExpenditure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShortExpenditure.Font = new System.Drawing.Font("HY견고딕", 9F, System.Drawing.FontStyle.Bold);
            this.btnShortExpenditure.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnShortExpenditure.Location = new System.Drawing.Point(134, 79);
            this.btnShortExpenditure.Name = "btnShortExpenditure";
            this.btnShortExpenditure.Size = new System.Drawing.Size(71, 23);
            this.btnShortExpenditure.TabIndex = 15;
            this.btnShortExpenditure.Text = "- 지출";
            this.btnShortExpenditure.UseVisualStyleBackColor = false;
            this.btnShortExpenditure.Click += new System.EventHandler(this.btnShortExpenditure_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(163, 57);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(18, 12);
            this.label21.TabIndex = 14;
            this.label21.Text = "원";
            // 
            // btnShortIncome
            // 
            this.btnShortIncome.BackColor = System.Drawing.Color.ForestGreen;
            this.btnShortIncome.FlatAppearance.BorderSize = 0;
            this.btnShortIncome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShortIncome.Font = new System.Drawing.Font("HY견고딕", 9F, System.Drawing.FontStyle.Bold);
            this.btnShortIncome.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnShortIncome.Location = new System.Drawing.Point(57, 78);
            this.btnShortIncome.Margin = new System.Windows.Forms.Padding(0);
            this.btnShortIncome.Name = "btnShortIncome";
            this.btnShortIncome.Size = new System.Drawing.Size(71, 23);
            this.btnShortIncome.TabIndex = 13;
            this.btnShortIncome.Text = "+ 수입";
            this.btnShortIncome.UseVisualStyleBackColor = false;
            this.btnShortIncome.Click += new System.EventHandler(this.btnShortIncome_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(36, 12);
            this.label22.TabIndex = 6;
            this.label22.Text = "내역:";
            // 
            // tbxShortContent
            // 
            this.tbxShortContent.Location = new System.Drawing.Point(57, 24);
            this.tbxShortContent.Name = "tbxShortContent";
            this.tbxShortContent.Size = new System.Drawing.Size(157, 21);
            this.tbxShortContent.TabIndex = 7;
            // 
            // tbxShortMoney
            // 
            this.tbxShortMoney.Location = new System.Drawing.Point(57, 51);
            this.tbxShortMoney.Name = "tbxShortMoney";
            this.tbxShortMoney.Size = new System.Drawing.Size(100, 21);
            this.tbxShortMoney.TabIndex = 9;
            this.tbxShortMoney.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 54);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 12);
            this.label23.TabIndex = 8;
            this.label23.Text = "금액:";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.btnLoad);
            this.groupBox4.Controls.Add(this.btnSave);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.btnNew);
            this.groupBox4.Controls.Add(this.tbxYear);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.tbxTargetAmount);
            this.groupBox4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox4.Location = new System.Drawing.Point(21, 44);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(397, 86);
            this.groupBox4.TabIndex = 23;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "연도 설정";
            // 
            // btnLoad
            // 
            this.btnLoad.BackColor = System.Drawing.Color.Orange;
            this.btnLoad.FlatAppearance.BorderSize = 0;
            this.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoad.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.btnLoad.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnLoad.Location = new System.Drawing.Point(292, 49);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(86, 23);
            this.btnLoad.TabIndex = 7;
            this.btnLoad.Text = "불러오기";
            this.btnLoad.UseVisualStyleBackColor = false;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Orange;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSave.Location = new System.Drawing.Point(200, 49);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(86, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "저장하기";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(230)))));
            this.groupBox5.Controls.Add(this.lblStatus);
            this.groupBox5.Controls.Add(this.lblBalance);
            this.groupBox5.Controls.Add(this.lblTotalExpenditure);
            this.groupBox5.Controls.Add(this.lblTotalIncome);
            this.groupBox5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox5.Location = new System.Drawing.Point(426, 44);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(213, 86);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "현재 상태";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblStatus.Location = new System.Drawing.Point(140, 40);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(62, 12);
            this.lblStatus.TabIndex = 3;
            this.lblStatus.Text = "상태: 흑자";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.lblBalance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblBalance.Location = new System.Drawing.Point(7, 60);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(54, 12);
            this.lblBalance.TabIndex = 2;
            this.lblBalance.Text = "잔액:0원";
            // 
            // lblTotalExpenditure
            // 
            this.lblTotalExpenditure.AutoSize = true;
            this.lblTotalExpenditure.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.lblTotalExpenditure.ForeColor = System.Drawing.Color.Red;
            this.lblTotalExpenditure.Location = new System.Drawing.Point(7, 40);
            this.lblTotalExpenditure.Name = "lblTotalExpenditure";
            this.lblTotalExpenditure.Size = new System.Drawing.Size(70, 12);
            this.lblTotalExpenditure.TabIndex = 1;
            this.lblTotalExpenditure.Text = "총 지출:0원";
            // 
            // lblTotalIncome
            // 
            this.lblTotalIncome.AutoSize = true;
            this.lblTotalIncome.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.lblTotalIncome.ForeColor = System.Drawing.Color.Blue;
            this.lblTotalIncome.Location = new System.Drawing.Point(7, 20);
            this.lblTotalIncome.Name = "lblTotalIncome";
            this.lblTotalIncome.Size = new System.Drawing.Size(70, 12);
            this.lblTotalIncome.TabIndex = 0;
            this.lblTotalIncome.Text = "총 수입:0원";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("HY견고딕", 9F);
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExit.Location = new System.Drawing.Point(658, 448);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(91, 27);
            this.btnExit.TabIndex = 16;
            this.btnExit.Text = "종료";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 487);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lbltext1);
            this.Name = "Form1";
            this.Text = "가계부 관리 시스템";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltext1;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxYear;
        private System.Windows.Forms.TextBox tbxTargetAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxIncomeMoney;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxIncomeContent;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbxIncomeDay;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbxIncomeMonth;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbxIncomeYear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnIncome;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbxExpenditureDay;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbxExpenditureMonth;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbxExpenditureYear;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnExpenditure;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbxExpenditureContent;
        private System.Windows.Forms.TextBox tbxExpenditureMoney;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnShortIncome;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbxShortContent;
        private System.Windows.Forms.TextBox tbxShortMoney;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnShortExpenditure;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblTotalIncome;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblTotalExpenditure;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lbIncome;
        private System.Windows.Forms.ListBox lbExpenditure;
        private System.Windows.Forms.ListBox lbAll;
    }
}

