﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace Proj_FinacialLedger_202244106
{
	public partial class Form1 : Form
	{

		public static string PATH  //파일 경로 - 없으면 파일 생성
		{
			get
			{
				var path = "c:\\class__c";
				if (false == Directory.Exists(path))
				{
					Directory.CreateDirectory(path);
				}
				return path;
			}
		}

		

        Dictionary<int, FinancialLedger> financialledges;
		public Form1()
		{
			InitializeComponent();

			financialledges = new Dictionary<int, FinancialLedger>();
			//OpenFile(ref);


		}



		//txt파일 찾기
		bool Can = true;
		private void btnNew_Click(object sender, EventArgs e)
		{
			//수입,지출,빠른입력 버튼 무효화시키기
			//연도,목표액 활성화
			//버튼 무효화
			Stop();

			Can = false;

			//string YearFullFileName = Path.Combine(PATH, $"{tbxYear.ToString()}.txt");
			//FinancialLedger data;
		}

		private void Stop()
		{
			tbxIncomeYear.ReadOnly = true;
			tbxIncomeMonth.ReadOnly = true;
			tbxIncomeDay.ReadOnly = true;
			tbxIncomeContent.ReadOnly = true;
			tbxIncomeMoney.ReadOnly = true;

			tbxExpenditureYear.ReadOnly = true;
			tbxExpenditureMonth.ReadOnly = true;
			tbxExpenditureDay.ReadOnly = true;
			tbxExpenditureContent.ReadOnly = true;
			tbxExpenditureMoney.ReadOnly = true;

			tbxShortContent.ReadOnly = true;
			tbxShortMoney.ReadOnly = true;

			tbxYear.ReadOnly = false;
			tbxTargetAmount.ReadOnly = false;
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			//파일에 저장
			//만약 목표액이 달라지는 경우에만 저장
			//FirstLineInfo();
			FinancialLedger ledger = new FinancialLedger(int.Parse(tbxYear.Text), int.Parse(tbxTargetAmount.Text));
			SaveYear(ledger);

			//수입,지출,빠른입력 무효화시키기
			//연도,목표액 활성화
			//버튼 활성화
			StopBreak();

			Can = true;
		}

		private void SaveYear(FinancialLedger data)
		{
			string filename = Path.Combine(PATH, $"{tbxYear.Text}.txt");

			try
			{
				using (var fs = new FileStream(filename, FileMode.Append))
				{
					using (var sw = new StreamWriter(fs))
					{
						sw.WriteLine(data.TargetAmount);
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void StopBreak()
		{
			tbxIncomeYear.ReadOnly = false;
			tbxIncomeMonth.ReadOnly = false;
			tbxIncomeDay.ReadOnly = false;
			tbxIncomeContent.ReadOnly = false;
			tbxIncomeMoney.ReadOnly = false;

			tbxExpenditureYear.ReadOnly = false;
			tbxExpenditureMonth.ReadOnly = false;
			tbxExpenditureDay.ReadOnly = false;
			tbxExpenditureContent.ReadOnly = false;
			tbxExpenditureMoney.ReadOnly = false;

			tbxShortContent.ReadOnly = false;
			tbxShortMoney.ReadOnly = false;

			tbxYear.ReadOnly = true;
			tbxTargetAmount.ReadOnly = true;
		}

		private void btnLoad_Click(object sender, EventArgs e)
		{
			lbIncome.Items.Clear();
			lbExpenditure.Items.Clear();
			lbAll.Items.Clear();
			string filename = Path.Combine(PATH, $"{tbxYear.Text}.txt");
			try
			{
				using (var fs = new FileStream(filename, FileMode.Open))
				{
					using (var sr = new StreamReader(fs))
					{
						int lineNumber = 0;
						while (!sr.EndOfStream)
						{
							var line = sr.ReadLine();
							if (!string.IsNullOrWhiteSpace(line))
							{
								if (lineNumber == 0)
								{
									tbxTargetAmount.Text = line;
									lineNumber++;
								}
								else
								{
									var parts = line.Split(',');
									if (parts.Length == 4)
									{
										string date = parts[0];
										string type = parts[1];
										string content = parts[2];
										string money = parts[3];

										string display = $"{content},{money}";
										if (type == "수입")
										{
											lbIncome.Items.Add(display);
											lbAll.Items.Add("수입," + display);
										}
										else if (type == "지출")
										{
											lbExpenditure.Items.Add(display);
											lbAll.Items.Add("지출," + display);
										}
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("파일이 존재하지 않거나 읽기 오류: " + ex.Message);
			}
		}

		private void btnIncome_Click(object sender, EventArgs e)//수입등록버튼
		{
			if (!Can)
			{
				MessageBox.Show("연도, 목표액을 입력해주세요");
				return;
			}

            int year;
            if (tbxYear.Text == null)
            {
                year = int.Parse(tbxYear.Text);

            }
            else
            {
                tbxYear.Text = tbxIncomeYear.Text;
                year = int.Parse(tbxYear.Text);
            }

            string filename = Path.Combine(PATH, $"{tbxYear.Text}.txt");//파일 위치 및 이름 저장
            int targetAmount;
            using (var fs = new FileStream(filename, FileMode.Open)) //파일 열기
            {
                using (var sr = new StreamReader(fs)) 
                {
                    {
                        tbxTargetAmount.Text = sr.ReadLine(); //목표액을 파일에서 불러옴
                        targetAmount = int.Parse(tbxTargetAmount.Text); 
                    }
                }
            }

            if (!financialledges.ContainsKey(year))
			{
				financialledges[year] = new FinancialLedger(year, targetAmount);
			}
			var ledger = financialledges[year];

			DateTime date = new DateTime(//년,월,일을 데이트타임 형변환
				int.Parse(tbxIncomeYear.Text),
				int.Parse(tbxIncomeMonth.Text),
				int.Parse(tbxIncomeDay.Text)
			);

			ledger.RegIncome(date, "수입", tbxIncomeContent.Text, int.Parse(tbxIncomeMoney.Text));

			var info = new Info(tbxIncomeContent.Text, int.Parse(tbxIncomeMoney.Text));
			lbIncome.Items.Add(info.ToString());
			lbAll.Items.Add("수입," + info.ToString());

			SaveLedgerToFile(year, ledger);
		}



		private void SaveLedgerToFile(int year, FinancialLedger ledger)//파일에 저장
		{
			string filename = Path.Combine(PATH, $"{year}.txt");
			try
			{
				using (var fs = new FileStream(filename, FileMode.Append))
				using (var sw = new StreamWriter(fs))
				{
					sw.WriteLine(ledger.TargetAmount);
					sw.WriteLine(ledger.Record);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("파일 저장 오류: " + ex.Message);
			}
		}

		private void btnExpenditure_Click(object sender, EventArgs e)
		{
			if (!Can)
			{
				MessageBox.Show("연도, 목표액을 입력해주세요");
				return;
			}
			int year;
			if (tbxYear.Text == null)
			{
				year = int.Parse(tbxYear.Text);

			}
			else
			{
                tbxYear.Text = tbxExpenditureYear.Text;
                year = int.Parse(tbxYear.Text);
            }

            string filename = Path.Combine(PATH, $"{tbxYear.Text}.txt");
            int targetAmount;
			using (var fs = new FileStream(filename, FileMode.Open))
			{
				using (var sr = new StreamReader(fs))
				{
					{
						tbxTargetAmount.Text = sr.ReadLine();
                        targetAmount = int.Parse(tbxTargetAmount.Text);
                    }
				}
			}       


			if (!financialledges.ContainsKey(year))
			{
				financialledges[year] = new FinancialLedger(year, targetAmount);
			}
			var ledger = financialledges[year];
			DateTime date = new DateTime(
				int.Parse(tbxExpenditureYear.Text),
				int.Parse(tbxExpenditureMonth.Text),
				int.Parse(tbxExpenditureDay.Text)
			);
			
			ledger.RegIncome(date, "지출", tbxExpenditureContent.Text, int.Parse(tbxExpenditureMoney.Text));
			
			var info = new Info(tbxExpenditureContent.Text, int.Parse(tbxExpenditureMoney.Text));
            lbExpenditure.Items.Add(info.ToString());
			lbAll.Items.Add("지출," + info.ToString());
			
			SaveLedgerToFile(year, ledger);
		}

        private void btnShortIncome_Click(object sender, EventArgs e)
        {
            if (!Can)
            {
                MessageBox.Show("연도, 목표액을 입력해주세요");
                return;
            }

            
            tbxYear.Text = DateTime.Now.ToString("yyyy");
            int year = int.Parse(tbxYear.Text);
            

            string filename = Path.Combine(PATH, $"{tbxYear.Text}.txt");
            int targetAmount;
            using (var fs = new FileStream(filename, FileMode.Open))
            {
                using (var sr = new StreamReader(fs))
                {
                    {
                        tbxTargetAmount.Text = sr.ReadLine();
                        targetAmount = int.Parse(tbxTargetAmount.Text);
                    }
                }
            }

            if (!financialledges.ContainsKey(year))
            {
                financialledges[year] = new FinancialLedger(year, targetAmount);
            }
            var ledger = financialledges[year];

            DateTime date = new DateTime(
               int.Parse(DateTime.Now.ToString("yyyy")),
               int.Parse(DateTime.Now.ToString("MM")),
               int.Parse(DateTime.Now.ToString("dd"))
            );

            ledger.RegIncome(date, "수입", tbxShortContent.Text, int.Parse(tbxShortMoney.Text));

            var info = new Info(tbxShortContent.Text, int.Parse(tbxShortMoney.Text));
            lbIncome.Items.Add(info.ToString());
            lbAll.Items.Add("수입," + info.ToString());

            SaveLedgerToFile(year, ledger);
        }

        private void btnShortExpenditure_Click(object sender, EventArgs e)
        {
            if (!Can)
            {
                MessageBox.Show("연도, 목표액을 입력해주세요");
                return;
            }
            
			tbxYear.Text = DateTime.Now.ToString("yyyy");
            int year = int.Parse(tbxYear.Text);

            string filename = Path.Combine(PATH, $"{tbxYear.Text}.txt");
            int targetAmount;
            using (var fs = new FileStream(filename, FileMode.Open))
            {
                using (var sr = new StreamReader(fs))
                {
                    {
                        tbxTargetAmount.Text = sr.ReadLine();
                        targetAmount = int.Parse(tbxTargetAmount.Text);
                    }
                }
            }


            if (!financialledges.ContainsKey(year))
            {
                financialledges[year] = new FinancialLedger(year, targetAmount);
            }
            var ledger = financialledges[year];
            DateTime date = new DateTime(
                int.Parse(DateTime.Now.ToString("yyyy")),
                int.Parse(DateTime.Now.ToString("MM")),
                int.Parse(DateTime.Now.ToString("dd"))
            );

            ledger.RegExpenditure(date, "지출", tbxShortContent.Text, int.Parse(tbxShortMoney.Text));

            var info = new Info(tbxShortContent.Text, int.Parse(tbxShortMoney.Text));
            lbExpenditure.Items.Add(info.ToString());
            lbAll.Items.Add("지출," + info.ToString());

            SaveLedgerToFile(year, ledger);
        }
    }
}

