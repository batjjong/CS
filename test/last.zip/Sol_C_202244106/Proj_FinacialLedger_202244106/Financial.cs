
using System;
using System.Collections.Generic;

namespace Proj_FinacialLedger_202244106
{
    abstract class Financial
    {
        protected Dictionary<DateTime, Info> _incomes = new Dictionary<DateTime, Info>();
        protected Dictionary<DateTime, Info> _expenditures = new Dictionary<DateTime, Info>();

        //public int TotalIncome => _incomes.Values.Sum(info => info.Money);
        //public int TotalExpenditure => _expenditures.Values.Sum(info => info.Money);

        public virtual bool RegIncome(DateTime indate, string divide, string info, int income)
        {
            if (income >= 0)
            {
                _incomes[indate] = new Info(info, income);
                return true;
            }
            return false;
        }

        public virtual bool RegExpenditure(DateTime expenddate, string divide, string info, int expenditure)
        {
            if (expenditure >= 0)
            {
                _expenditures[expenddate] = new Info(info, expenditure);
                return true;
            }
            return false;
        }

        public virtual bool RegIncome(string divide, string info, int income)
        {
            return RegIncome(DateTime.Now, divide, info, income);
        }

        public virtual bool RegExpenditure(string divide, string info, int expenditure)
        {
            return RegExpenditure(DateTime.Now, divide, info, expenditure);
        }
    }
}
