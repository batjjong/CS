
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_FinacialLedger_202244106
{
    class FinancialLedger : Financial
    {
        private int _year;
        private int _targetAmount;

        public int Year => _year;
        public int TargetAmount => _targetAmount;
        //public bool IsBlack => TotalIncome > TotalExpenditure;

        public FinancialLedger(int year)
        {
            _year = year;
        }

        public FinancialLedger(int year, int targetAmount)
        {
            _year = year;
            _targetAmount = targetAmount;
        }

        public override bool RegIncome(DateTime indate, string divide, string info, int income)
        {
            if (_year.ToString() == indate.ToString("yyyy"))
            {
                return base.RegIncome(indate, divide, info, income);
            }
            return false;
        }

        public override bool RegExpenditure(DateTime expenddate, string divide, string info, int expenditure)
        {
            if (_year.ToString() == expenddate.ToString("yyyy"))
            {
                return base.RegExpenditure(expenddate, divide, info, expenditure);
            }
            return false;
        }

        public override bool RegIncome(string divide, string info, int income)
        {
            if (_year.ToString() == DateTime.Now.ToString("yyyy"))
            {
                return base.RegIncome(DateTime.Now, divide, info, income);
            }
            return false;
        }

        public override bool RegExpenditure(string divide, string info, int expenditure)
        {
            if (_year.ToString() == DateTime.Now.ToString("yyyy"))
            {
                return base.RegExpenditure(DateTime.Now, divide, info, expenditure);
            }
            return false;
        }

        public string Record
        {
            get
            {
                var sb = new StringBuilder();
                foreach (var kv in _incomes)
                {
                    sb.AppendLine($"{kv.Key:yyyyMMdd},수입,{kv.Value.Content},{kv.Value.Money}");
                }
                foreach (var kv in _expenditures)
                {
                    sb.AppendLine($"{kv.Key:yyyyMMdd},지출,{kv.Value.Content},{kv.Value.Money}");
                }
                return sb.ToString().TrimEnd();
            }
        }
    }
}
