﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Week09Homework
{
    class Grade : IFile
    {
        public const int MAX_GRADE_COUNT = 9;

        private string _studentNumber;
        public string StudentNumber
        {
            get { return _studentNumber; }
        }

        private List<double> _scores = new List<double>();

        public Grade(string studentNumber)
        {
            _studentNumber = studentNumber;
                       
        }

        public int Count()
        {
            return _scores.Count;
        }
        public double Get(int i)
        {
            return _scores[i];
        }

        public double Average()
        {
            if (this._scores.Count == 0) {
                return -1.0;
            }

            double sum = 0.0;
            foreach (var score in this._scores) {
                sum += score;
            }
            return sum / _scores.Count;
        }

        public void Clear()
        {
            _scores.Clear();
        }

        public bool Add(double score)
        {
            if (_scores.Count >= Grade.MAX_GRADE_COUNT) {
                return false;
            }

            _scores.Add(score);
            return true;
        }

        public string Record
        {
            get
            {
                if (string.IsNullOrEmpty(_studentNumber))
                    return string.Empty;

                // 점수 문자열 만들기
                var scorePart = _scores.Count > 0 ? string.Join(",", _scores) : "";
                                
                // 소수점 한 자리로 저장하고 싶으면 avg.ToString("F1") 사용
                return $"{scorePart}";
            }
        }

        public static Grade Restore(string record)
        {
            if (string.IsNullOrEmpty(record)) return null;
            
            var parts = record.Split(',');
            if (parts.Length < 1) return null;

            var grade = new Grade(parts[0]);
            

            //점수부분
            for (int i = 0; i < parts.Length; i++)
            {
                if (double.TryParse(parts[i], out double score))
                    grade.Add(score);
            }
            return grade;

            
        }
    }
}