﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Week09Homework
{

    public partial class FormManager : Form
    {
        public static string PATH
        {
            get
            {
                var path = "c:\\class_c";
                if (false == Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                return path;
            }
        }

        public static string SUBPATH
        {
            get
            {
                var path = PATH + "\\scores";
                if (false == Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                return path;
            }
        }

        public static string DepartmentFullFileName//학과.txt파일 위치
        {
            get
            {
                return Path.Combine(PATH, "deapratment.txt");
            }
        }
        //확장자:.txt
        //텍스트계열확장: txt ini html json csv xml
        //바이너리계열확장자:bin dat png mp3
        public static string ProfessorFullFileName//교수.txt파일 위치
        {
            get
            {
                return Path.Combine(PATH, "professor.txt");
            }
        }
        public static string StudentFullFileName//학생.txt파일 위치
        {
            get
            {
                return Path.Combine(PATH, "student.txt");
            }
        }
        
        Department[] departments; //변수 이름 설정
        List<Professor> professors;
        Dictionary<string, Student> students;

        List<Grade> testGrades;
        TextBox[] tbxTestScores;

        public FormManager()
        {
            InitializeComponent();

            departments = new Department[100]; //변수 지정
            professors = new List<Professor>();
            students = new Dictionary<string, Student>();

            for (int i = 0; i < (int)YEAR.END; i++)
            {
                cmbYear.Items.Add(Student.YearName[(YEAR)i]);
            }//학년

            cmbClass.Items.AddRange(new object[] { CLASS.A, CLASS.B, CLASS.C });//반

            for (int i = 0; i < (int)REG_STATUS.END; i++)
            {
                cmbRegStatus.Items.Add(Student.RegStatusName[(REG_STATUS)i]);
            }//재학상태

            testGrades = new List<Grade>();
            tbxTestScores = new TextBox[] {
                tbxTestScore1,
                tbxTestScore2,
                tbxTestScore3,
                tbxTestScore4,
                tbxTestScore5,
                tbxTestScore6,
                tbxTestScore7,
                tbxTestScore8,
                tbxTestScore9,
            };

            //ref : 포인터,주소반환
            OpenInfo(ref departments, DepartmentFullFileName);
            OpenInfo(ref professors, ProfessorFullFileName);
            OpenInfo(ref students, StudentFullFileName);
        }

        private void OpenInfo(ref Department[] departments, string filename)//파일읽기 배열
        {
            if (departments == null && departments.Length != 100) {
                departments = new Department[100];
            }
            if (true == File.Exists(filename)) {//파일이 있으면
                try {
                    using (var fs = new FileStream(filename, FileMode.Open)) {
                        using (var sr = new StreamReader(fs)) {
                            int deptIndex = 0;
                            while (false == sr.EndOfStream) {//마지막줄까지
                                var data = sr.ReadLine();//줄읽기
                                var dept = Department.Restore(data);//내용 자르기
                                if (dept != null && deptIndex < departments.Length) {
                                    departments[deptIndex++] = dept;
                                    lbxDepartment.Items.Add(dept);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex) {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        private void OpenInfo(ref List<Professor> professors, string filename)//파일읽기 리스트
        {
            if (professors == null)
            {
                professors = new List<Professor>();
            }
            try
            {
                if (true == File.Exists(filename)) {
                    using (var fs = new FileStream(filename, FileMode.Open)) {
                        using (var sr = new StreamReader(fs)) {
                            while (false == sr.EndOfStream) {
                                var data = sr.ReadLine();
                                var prof = Professor.Restore(data, departments);
                                if (prof != null) {
                                    professors.Add(prof);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void OpenInfo(ref Dictionary<string, Student> students, string filename)//파일읽기 딕셔너리
        {
            if (students == null) {
                students = new Dictionary<string, Student>();
            }
            try 
            {
                if (true == File.Exists(filename)) {
                    using (var fs = new FileStream(filename, FileMode.Open)) {
                        using (var sr = new StreamReader(fs)) {
                            while (false == sr.EndOfStream) {
                                var data = sr.ReadLine();
                                var student = Student.Restore(data, departments);
                                if (student != null) {
                                    students[student.Number] = student;
                                    lbxDictionary.Items.Add(student);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        
        private void SaveInfo(IFile data, string filename)//파일에 저장
        {
            try
            {
                using (var fs = new FileStream(filename, FileMode.Append))//파일에 추가
                {
                    using (var sw = new StreamWriter(fs))
                    {
                        sw.WriteLine(data.Record);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DeleteInfo(Department[] departments, string filename)//파일삭제
        {
            using (var fs = new FileStream(filename, FileMode.Append))//파일에 추가인데 이 이유가 lbl을 보고 저장하기 때문
            {
                using (var sw = new StreamWriter(fs))
                {
                    foreach (var dept in departments)
                    {
                        sw.WriteLine(dept.Record);
                    }
                }
            }
        }

        private void DeleteInfo(List<Professor> professors, string filename)
        {
            using (var fs = new FileStream(filename, FileMode.Create))//파일에 생성, lbl을 보고 저장
            {
                using (var sw = new StreamWriter(fs))
                {
                    foreach (var prof in professors)
                    {
                        sw.WriteLine(prof.Record);
                    }
                }
            }
        }

        private void btnRegisterDepartment_Click(object sender, EventArgs e)//학과 등록 버튼
        {
            if (string.IsNullOrEmpty(tbxDepartmentCode.Text))
            {
                MessageBox.Show("학과코드 입력");
                tbxDepartmentCode.Focus();
                return;
            }

            if (string.IsNullOrEmpty(tbxDepartmentName.Text) || tbxDepartmentName.ToString().Trim().Length <  2)
            {
                MessageBox.Show("학과이름을 2자 이상 입력해주세요");
                tbxDepartmentName.Focus();
                return;
            }

            int index = -1;
            for (int i = 0; i < departments.Length; i++)
            {
                if (departments[i] == null)
                {
                    if (index < 0)
                    {
                        index = i;
                    }
                }
                else
                {
                    if (departments[i].GetCode() == tbxDepartmentCode.Text)
                    {
                        MessageBox.Show("중복 학과코드");
                        tbxDepartmentCode.Focus();
                        return;
                    }
                }
            }

            if (index < 0)
            {
                MessageBox.Show("신규 학과를 개설할 수 없습니다.");
                return;
            }

            Department dept = new Department(tbxDepartmentCode.Text, tbxDepartmentName.Text);

            departments[index] = dept;

            lbxDepartment.Items.Add(dept);
            //file - append
            //열기 - 추가 - 닫기
            SaveInfo(dept, DepartmentFullFileName);
        }


        /*private void SaveInfo(Department depertment, string filename)
        {
            using (var fs = new FileStream(filename, FileMode.Append))
            {
                using (var sw = new StreamWriter(fs))
                {
                    foreach (var dept in departments)
                    {
                        sw.WriteLine(dept.Record);
                    }
                }
            }
        }*/

        private void btnRemoveDepartment_Click(object sender, EventArgs e)//학과 제거 버튼
        {
            if (lbxDepartment.SelectedIndex < 0)
            {
                MessageBox.Show("삭제할 학과를 선택");
                return;
            }

            if (lbxDepartment.SelectedItem is Department)
            {
                var target = (Department)lbxDepartment.SelectedItem;

                foreach (var prof in professors)//담당교수면 삭제 불가
                {
                    if (prof.Dept.Code == target.Code)
                    {
                        MessageBox.Show("");
                        return;
                    }
                }

                foreach (var stu in students)//학과에 학생있으면 삭제 불가
                {
                    if (stu.Value.Dept.Code == target.Code)
                    {
                        MessageBox.Show("");
                        return;
                    }
                }

                for (int i = 0; i < departments.Length; i++)
                {
                    if (departments[i] != null && departments[i] == target)
                    {
                        departments[i] = null;
                        break;
                    }
                }

                lbxDepartment.Items.RemoveAt(lbxDepartment.SelectedIndex);//lbx에서 아이템 삭제
                lbxDepartment.SelectedIndex = -1;//lbx선택 취소
            }
            
            if (departments.Contains(lbxDepartment.SelectedItem))//학과에 선택한 과가 있으면
            {
                using (var fs = new FileStream(DepartmentFullFileName, FileMode.Create))//파일을 만든다
                {
                    using (var sw = new StreamWriter(fs))
                    {
                        foreach (var dept in departments)//모든학과가 반복
                        {
                            sw.WriteLine(dept.Record);//한줄씩 저장
                        }
                    }
                }
            }
            
            DeleteInfo(departments, DepartmentFullFileName);
        }

        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabMain.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    cmbProfessorDepartment.Items.Clear();
                    foreach (var department in departments)
                    {
                        if (department != null)
                        {
                            cmbProfessorDepartment.Items.Add(department);
                        }
                    }

                    cmbProfessorDepartment.SelectedIndex = -1;
                    lbxProfessor.Items.Clear();
                    break;
                case 2:
                    cmbDepartment.Items.Clear();
                    foreach (var department in departments)
                    {
                        if (department != null)
                        {
                            cmbDepartment.Items.Add(department);
                        }
                    }

                    ClearStudentInfo();
                    break;
                case 3:
                    ClearTestScoreInfo();
                    break;
                default:
                    break;
            }
        }
        
        private void ClearTestScoreInfo()
        {
            lblTestName.Text = string.Empty;

            foreach (var textbox in tbxTestScores)
            {
                textbox.Text = string.Empty;
            }
        }

        private void cmbProfessorDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProfessorDepartment.SelectedIndex < 0)
            {
                return;
            }

            lbxProfessor.Items.Clear();

            var department = cmbProfessorDepartment.SelectedItem as Department;

            if (department != null)
            {
                foreach (var professor in professors)
                {
                    if (professor != null && professor.Dept.Code == department.Code)
                    {
                        lbxProfessor.Items.Add(professor);
                    }
                }
            }
        }

        private void btnRegisterProfessor_Click(object sender, EventArgs e)
        {
            if (cmbProfessorDepartment.SelectedIndex < 0)
            {
                MessageBox.Show("학과를 선택");
                cmbProfessorDepartment.Focus();
                return;
            }

            if (false == cmbProfessorDepartment.SelectedItem is Department dept)
            {
                MessageBox.Show("학과정보에 이상 발생");
                cmbProfessorDepartment.Focus();
                return;
            }

            if (string.IsNullOrEmpty(tbxProfessorNumber.Text))
            {
                MessageBox.Show("교수번호 입력");
                tbxProfessorNumber.Focus();
                return;
            }

            if (string.IsNullOrEmpty(tbxProfessorName.Text))
            {
                MessageBox.Show("교수이름 입력");
                tbxProfessorName.Focus();
                return;
            }

            for (int i = 0; i < professors.Count; i++)
            {
                if (professors[i].Number == tbxProfessorNumber.Text)
                {
                    MessageBox.Show("중복 교수코드");
                    tbxProfessorNumber.Focus();
                    return;
                }
            }

            Professor professor = new Professor(tbxProfessorNumber.Text, tbxProfessorName.Text, dept);

            professors.Add(professor);
            lbxProfessor.Items.Add(professor);

            SaveInfo(professor, ProfessorFullFileName);
        }

        private void btnRemoveProfessor_Click(object sender, EventArgs e)
        {
            if (lbxProfessor.SelectedIndex < 0)
            {
                MessageBox.Show("삭제할 교수를 선택");
                return;
            }



            if (lbxProfessor.SelectedItem is Professor)
            {
                var target = (Professor)lbxProfessor.SelectedItem;

                foreach (var stu in students)
                {
                    if (stu.Value.AdvisorNumber == target.Number)
                    {
                        MessageBox.Show("사용중인 교수입니다");
                        return;
                    }
                }

                for (int i = 0; i < professors.Count; i++)
                {
                    if (professors[i] != null && professors[i] == target)
                    {
                        professors.RemoveAt(i);
                        break;
                    }
                }

                lbxProfessor.Items.Remove(target);
                lbxProfessor.SelectedIndex = -1;

                DeleteInfo(professors, ProfessorFullFileName);
            }
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbAdvisor.Items.Clear();

            if (cmbDepartment.SelectedIndex < 0)
            {
                return;
            }

            if (false == cmbDepartment.SelectedItem is Department dept)
            {
                return;
            }

            foreach (var professor in professors)
            {
                if (professor != null && professor.Dept.Code == dept.Code)
                {
                    cmbAdvisor.Items.Add(professor);
                }
            }

            cmbAdvisor.SelectedIndex = -1;
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearStudentInfo();
            lbxDictionary.SelectedIndex = -1;
        }

        private void ClearStudentInfo()
        {
            tbxNumber.Text = "20";
            tbxName.Text = string.Empty;
            tbxBirthYear.Text = "20";
            tbxBirthMonth.Text = "";
            tbxBirthDay.Text = "";
            cmbDepartment.SelectedIndex = -1;
            cmbAdvisor.SelectedIndex = -1;
            cmbYear.SelectedIndex = -1;
            cmbClass.SelectedIndex = -1;
            cmbRegStatus.SelectedIndex = -1;
            tbxAddress.Text = string.Empty;
            tbxContact.Text = string.Empty;

            tbxNumber.ReadOnly = false;
            selectedStudent = null;
            btnRegister.Text = "등록";
        }

        Student selectedStudent = null;
        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (selectedStudent == null)
            {
                RegisterStudent();
            }
            else
            {
                UpdateStudent();          //call
            }
        }

        private void RegisterStudent()
        {
            var number = tbxNumber.Text.Trim();

            if (string.IsNullOrEmpty(number) || number.Length != 8)
            {
                tbxNumber.Focus();
                return;
            }

            if (string.IsNullOrEmpty(tbxName.Text) || tbxName.Text.Trim().Length < 2)
            {
                tbxName.Focus();
                return;
            }

            //for, 성능 떨어짐
            for (int i = 0; i < students.Count; i++)
            {
                var pair = students.ElementAt(i);
                if (pair.Key == number)
                {
                    tbxNumber.Focus();
                    return;
                }
            }

            //foreach
            foreach (var pair in students)
            {
                if (pair.Key == number)
                {
                    tbxNumber.Focus();
                    return;
                }
            }

            //실제 많이 사용하는 방법1
            if (true == students.ContainsKey(number))
            {
                tbxNumber.Focus();
                return;
            }

            Student student = new Student(number, tbxName.Text.Trim());

            int birthYear, birthMonth;// birthDay;
            if (true == int.TryParse(tbxBirthYear.Text, out birthYear))
            {
                if (birthYear < 1900 || 9000 < birthYear)
                {
                    tbxBirthYear.Focus();
                    return;
                }
            }
            else
            {
                tbxBirthYear.Focus();
                return;
            }

            if (true == int.TryParse(tbxBirthMonth.Text, out birthMonth))
            {
                if (birthMonth < 1 || 12 < birthMonth)
                {
                    tbxBirthMonth.Focus();
                    return;
                }
            }
            else
            {
                tbxBirthMonth.Focus();
                return;
            }

            if (true == int.TryParse(tbxBirthDay.Text, out int birthDay))
            {
                //2월, 달 처리등은 추후 해볼것
                if (birthDay < 0 || 31 < birthDay)
                {
                    tbxBirthDay.Focus();
                    return;
                }
            }
            else
            {
                tbxBirthDay.Focus();
                return;
            }

            student.SetBirthInfo(birthYear, birthMonth, birthDay);

            if (cmbDepartment.SelectedIndex < 0)
            {
                student.Dept = null;
            }
            else
            {
                student.Dept = (cmbDepartment.SelectedItem as Department);
            }

            if (cmbAdvisor.SelectedIndex < 0)
            {
                student.AdvisorNumber = null;
            }
            else
            {
                student.AdvisorNumber = (cmbAdvisor.SelectedItem as Professor).Number;
            }

            if (cmbYear.SelectedIndex < (int)YEAR.END)
            {
                student.Year = (YEAR)cmbYear.SelectedIndex;
            }

            if (cmbClass.SelectedIndex < 0)
            {
                cmbClass.Focus();
                return;
            }
            student.Class = (CLASS)cmbClass.SelectedIndex;

            if (cmbRegStatus.SelectedIndex < 0)
            {
                cmbRegStatus.Focus();
                return;
            }
            student.RegStatus = (REG_STATUS)cmbRegStatus.SelectedIndex;

            student.Address = tbxAddress.Text.Trim();
            student.Contact = tbxContact.Text.Trim();

            students[number] = student;
            lbxDictionary.Items.Add(student);

            SaveInfo(student, StudentFullFileName);
        }
        
        private void UpdateStudent()
        {
            if (string.IsNullOrEmpty(tbxName.Text) || tbxName.Text.Trim().Length < 2)
            {
                tbxName.Focus();
                return;
            }

            if (true == int.TryParse(tbxBirthYear.Text, out int birthYear))
            {
                if (birthYear < 1900 || 9000 < birthYear)
                {
                    tbxBirthYear.Focus();
                    return;
                }
            }
            else
            {
                tbxBirthYear.Focus();
                return;
            }


            if (true == int.TryParse(tbxBirthMonth.Text, out int birthMonth))
            {
                if (birthMonth < 1 || 12 < birthMonth)
                {
                    tbxBirthMonth.Focus();
                    return;
                }
            }
            else
            {
                tbxBirthMonth.Focus();
                return;
            }

            if (true == int.TryParse(tbxBirthDay.Text, out int birthDay))
            {
                //2월, 달 처리등은 추후 해볼것
                if (birthDay < 0 || 31 < birthDay)
                {
                    tbxBirthDay.Focus();
                    return;
                }
            }
            else
            {
                tbxBirthDay.Focus();
                return;
            }

            if (cmbDepartment.SelectedIndex < 0)
            {
                //cmbDepartment.Focus();
                return;
            }

            /*if (cmbYear.SelectedIndex < 0)
            {
                cmbYear.Focus();
                return;
            }*/

            if (cmbYear.SelectedIndex < 0)
            {
                cmbYear.Focus();
                return;
            }
            /////////////////////////////////////////////////////////////////////////////
            if (cmbClass.SelectedIndex < 0)
            {
                cmbClass.Focus();
                return;
            }

            if (cmbRegStatus.SelectedIndex < 0)
            {
                cmbRegStatus.Focus();
                return;
            }

            selectedStudent.SetBirthInfo(birthYear, birthMonth, birthDay);

            if (cmbDepartment.SelectedIndex < 0)
            {
                selectedStudent.Dept = null;
            }
            else
            {
                selectedStudent.Dept = (cmbDepartment.SelectedItem as Department);
            }

            if (cmbAdvisor.SelectedIndex < 0)
            {
                selectedStudent.AdvisorNumber = null;
            }
            else
            {
                selectedStudent.AdvisorNumber = (cmbAdvisor.SelectedItem as Professor).Number;
            }

            selectedStudent.Year = (YEAR)cmbYear.SelectedIndex;
            selectedStudent.Class = (CLASS)cmbClass.SelectedIndex;
            selectedStudent.RegStatus = (REG_STATUS)cmbRegStatus.SelectedIndex;
            selectedStudent.Address = tbxAddress.Text.Trim();
            selectedStudent.Contact = tbxContact.Text.Trim();

            UpdateInfo(students, StudentFullFileName);

            MessageBox.Show("수정완료");
            lbxDictionary.SelectedIndex = -1;
            ClearStudentInfo();
        }

        private void UpdateInfo(Dictionary<string, Student> students, string filename)
        {
            using (var fs = new FileStream(filename, FileMode.Create))
            {
                using (var sw = new StreamWriter(fs))
                {
                    foreach (var stu in students)
                    {
                        sw.WriteLine(stu.Value.Record);
                    }
                }
            }
        }

        private void lbxDictionary_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxDictionary.SelectedIndex < 0)
            {
                return;
            }

            var student = (lbxDictionary.SelectedItem as Student);

            ClearStudentInfo();

            if (student != null)
            {
                DisplaySelectedStudent(student);
            }
        }

        private void DisplaySelectedStudent(Student student)
        {
            selectedStudent = student;
            tbxNumber.ReadOnly = true;

            tbxNumber.Text = student.Number;
            tbxName.Text = student.Name;
            tbxBirthYear.Text = student.BirthInfo.Year.ToString();
            tbxBirthMonth.Text = student.BirthInfo.Month.ToString();
            tbxBirthDay.Text = student.BirthInfo.Day.ToString();

            for (int i = 0; i < cmbDepartment.Items.Count; i++)
            {
                if ((cmbDepartment.Items[i] as Department).Code == student.Dept.Code)
                {
                    cmbDepartment.SelectedIndex = i;
                    break;
                }
            }

            for (int i = 0; i < cmbAdvisor.Items.Count; i++)
            {
                if ((cmbAdvisor.Items[i] as Professor).Number == student.AdvisorNumber)
                {
                    cmbAdvisor.SelectedIndex = i;
                    break;
                }
            }

            for (int i = 0; i < cmbYear.Items.Count; i++)
            {
                if (i == (int)student.Year)
                {
                    cmbYear.SelectedIndex = i;
                    break;
                }
            }
            
            for (int i = 0; i < cmbClass.Items.Count; i++)
            {
                if (i == (int)student.Class)
                {
                    cmbClass.SelectedIndex = i;
                    break;
                }
            }

            for (int i = 0; i < cmbRegStatus.Items.Count; i++)
            {
                if (i == (int)student.RegStatus)
                {
                    cmbRegStatus.SelectedIndex = i;
                    break;
                }
            }

            tbxAddress.Text = selectedStudent.Address;
            tbxContact.Text = selectedStudent.Contact;

            btnRegister.Text = "수정";
        }

        private void btnTestSearchStudent_Click(object sender, EventArgs e)
        {
            ClearTestScoreInfo();

            var number = tbxTestNumber.Text.Trim();
            if (string.IsNullOrEmpty(number) || number.Length != 8)
            {
                tbxNumber.Focus();
                return;
            }

            selectedStudent = SearchStudentByNumber(tbxTestNumber.Text);

            if (selectedStudent == null)
            {
                MessageBox.Show($"{number}학번의 학생 정보가 없음");
                tbxTestNumber.Focus();
                return;
            }

            lblTestName.Text = selectedStudent.Name;

            string filepath = Path.Combine(SUBPATH, $"{selectedStudent.Number}.txt");

            if (File.Exists(filepath))
            {
                var data = File.ReadAllLines(filepath);
                if (data.Length > 0)
                {
                    var loadedGrade = Grade.Restore(data[data.Length-1]);
                    if (loadedGrade != null)
                    {
                        for (int i = 0; i < loadedGrade.Count() && i < tbxTestScores.Length; i++)
                        {
                            tbxTestScores[i].Text = loadedGrade.Get(i).ToString("0.0");
                        }
                        lblTestTotalCount.Text = loadedGrade.Count().ToString();
                        lblTestAverage.Text = loadedGrade.Average().ToString("F1");
                    }
                }
            }

            Grade grade = SearchGradeByNumber(selectedStudent.Number);

            
        }
        
        Grade SearchGradeByNumber(string number)
        {
            foreach (Grade grade in testGrades)
            {
                if (grade.StudentNumber == number)
                {
                    return grade;
                }
            }

            return null;
        }

        private Student SearchStudentByNumber(string number)
        {
            if (students.ContainsKey(number))
            {
                return students[number];
            }
            else
            {
                return null;
            }
        }

        private void btnTestRegScore_Click(object sender, EventArgs e)
        {
            lblTestTotalCount.Text = "";
            lblTestAverage.Text = "";

            if (selectedStudent == null)
            {
                tbxTestNumber.Focus();
                return;
            }

            for (int i = 1; i < tbxTestScores.Length; i++)
            {
                if (true == string.IsNullOrEmpty(tbxTestScores[i - 1].Text) && false == string.IsNullOrEmpty(tbxTestScores[i].Text))
                {
                    tbxTestScores[i - 1].Focus();
                    return;
                }
            }

            var grade = SearchGradeByNumber(selectedStudent.Number);

            if (grade == null)
            {
                grade = new Grade(selectedStudent.Number);
            }

            grade.Clear();

            double temp;
            for (int i = 0; i < tbxTestScores.Length; i++)
            {
                if (string.IsNullOrEmpty(tbxTestScores[i].Text))
                {
                    break;
                }

                if (false == double.TryParse(
                    tbxTestScores[i].Text, out temp))
                {
                    tbxTestScores[i].Focus();
                    return;
                }
                grade.Add(temp);
            }

            testGrades.Add(grade);

            lblTestTotalCount.Text = grade.Count().ToString();

            double average = grade.Average();
            lblTestAverage.Text = average.ToString("F1");

            string ScoreFullFileName = Path.Combine(SUBPATH, $"{selectedStudent.Number}.txt");
            
            UpdateInfo(testGrades, ScoreFullFileName);
        }

        private void UpdateInfo(List<Grade> data, string filename)
        {
            using (var fs = new FileStream(filename, FileMode.Append))
            {
                using (var sw = new StreamWriter(fs))
                {
                    foreach (var grade in data)
                    {
                        sw.WriteLine(grade.Record);
                    }
                }
            }
        }
    }
}
