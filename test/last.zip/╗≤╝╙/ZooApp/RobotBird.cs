﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZooApp
{
    class RobotBird : Animal,IRobot
    {
        private int _batteryLevel;

        public int BatteryLevel 
        {
            get { return _batteryLevel; }
            set {
                if (value > 1000) {
                    _batteryLevel = 1000;
                }
                else {
                    _batteryLevel = value;
                }
            }
        }

        public RobotBird(string name, COLOR color, int batteryLevel) : base(name,color)
        {
            _batteryLevel = batteryLevel;
        }

        public override string ToString()
        {
            return $"ROBOTBIRD:{Name}";
        }

        public string Fly(int count)
        {
            string retValue = "";
            for (int i = 0; i < count; i++)
            {
                retValue += "푸드득~";
            }
            return retValue;
        }

        protected override bool AddLevel(int level)
        {
            if (_level + level <= 50){
                _level += level;
                return true;
            }
            else{
                _level = 50;
                return false;
            }
        }

        public void Charge() 
        {
            BatteryLevel = 1000;
        }
    }
}
